<?php

// Paramètres de configuration de la base de données
$databaseConfig = [
    'host' => 'localhost',
    'port' => 3306,
    'dbname' => 'devoir_dev',
    'username' => 'root',
    'password' => ''
];

try {
    // Création de la connexion à la base de données
    $dsn = 'mysql:host=' . $databaseConfig['host'] . ';port=' . $databaseConfig['port'] . ';dbname=' . $databaseConfig['dbname'];
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, // Mode de gestion des erreurs
        PDO::ATTR_EMULATE_PREPARES => false, // Désactiver l'émulation des requêtes préparées
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8" // Encodage des caractères
    ];

    // Création de l'objet PDO avec des options de sécurité supplémentaires
    $pdo = new PDO($dsn, $databaseConfig['username'], $databaseConfig['password'], $options);

    // Activation de l'échappement des requêtes préparées pour se protéger contre les injections SQL
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

    // Activation du mode strict des requêtes préparées pour se protéger contre les injections SQL
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->setAttribute(PDO::ATTR_STRINGIFY_FETCHES, false);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}
?>
