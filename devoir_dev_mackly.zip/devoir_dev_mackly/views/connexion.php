<!DOCTYPE html>
<html>
<head>
    <title>Connexion</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
    <style>
        /* Styles CSS personnalisés */

        /* Styles pour le fond de la page */
        body {
            background-color: #f9f9f9;
            background-image: url('https://image.freepik.com/vetores-gratis/ilustracao-do-conceito-isometrico-de-ciberseguranca_114482-111.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }

        /* Styles pour le formulaire */
        form {
            max-width: 400px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }

        /* Styles pour les messages d'erreur */
        .error-message {
            color: red;
            font-weight: bold;
            text-align: center;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <h2>Connexion</h2>
    <?php if (isset($erreur)) { echo "<p class='error-message'>$erreur</p>"; } ?>
    <form method="post" action="../controllers/connexioncontroller.php">
        <label for="email">Email :</label>
        <input type="text" id="email" name="email" required><br><br>
        <label for="mot_de_passe">Mot de passe :</label>
        <input type="password" id="mot_de_passe" name="mot_de_passe" required><br><br>
        <input type="submit" value="Se connecter">
    </form>
</body>
</html>
