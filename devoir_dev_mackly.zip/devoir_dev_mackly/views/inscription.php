<!DOCTYPE html>
<html>
<head>
    <title>Inscription</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
    <style>

        /* Styles pour le fond de la page */
        body {
            background-color: #f9f9f9;
            background-image: url('https://image.freepik.com/vetores-gratis/ilustracao-do-conceito-isometrico-de-ciberseguranca_114482-111.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }

        /* Styles pour l'en-tête */
        h2 {
            color: #333;
            text-align: center;
            margin-top: 50px;
        }

        /* Styles pour le formulaire */
        form {
            max-width: 400px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="date"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }

        /* Styles pour les messages d'erreur */
        .error-message {
            color: red;
            font-weight: bold;
            text-align: center;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <h2>Inscription</h2>
    <?php if (isset($erreur)) { echo "<p class='error-message'>$erreur</p>"; } ?>
    <form method="post" action="../controllers/InscriptionController.php">
        <label for="nom">Nom :</label>
        <input type="text" id="nom" name="nom" required><br><br>
        <label for="prenom">Prénom :</label>
        <input type="text" id="prenom" name="prenom" required><br><br>
        <label for="adresse">Adresse :</label>
        <input type="text" id="adresse" name="adresse" required><br><br>
        <label for="email">Email :</label>
        <input type="email" id="email" name="email" required><br><br>
        <label for="num_mobile">Numéro de mobile :</label>
        <input type="text" id="num_mobile" name="num_mobile" required><br><br>
        <label for="mot_de_passe">Mot de passe :</label>
        <input type="password" id="mot_de_passe" name="mot_de_passe" required><br><br>
        <label for="date_recrutement">Date de recrutement :</label>
        <input type="date" id="date_recrutement" name="date_recrutement" required><br><br>
        <input type="submit" value="S'inscrire">
    </form>
</body>
</html>
