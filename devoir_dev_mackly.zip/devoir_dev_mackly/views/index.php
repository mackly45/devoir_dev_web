<!DOCTYPE html>
<html>
<head>
    <title>Page d'accueil</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
    <style>
        /* Styles CSS personnalisés */

        /* Styles pour le fond de la page */
        body {
            background-color: #f9f9f9;
            background-image: url('https://image.freepik.com/vetores-gratis/ilustracao-do-conceito-isometrico-de-ciberseguranca_114482-111.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }

        /* Styles pour le conteneur */
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding-top: 100px;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 30px;
        }

        p {
            color: #555;
        }

        a {
            color: #333;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Bienvenue sur la page d'accueil</h1>
        <p>Ceci est une page d'accueil fictive.</p>
        <p>Pour vous inscrire, veuillez cliquer sur le lien suivant : <a href="inscription.php">Inscription</a></p>
        <p>Si vous avez déjà un compte, vous pouvez vous connecter ici : <a href="connexion.php">Connexion</a></p>
    </div>
</body>
</html>
