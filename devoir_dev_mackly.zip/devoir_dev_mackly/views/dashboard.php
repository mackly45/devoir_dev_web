<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
    <title>Tableau de bord</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
    <style>
        /* Styles CSS personnalisés */

        /* Styles pour le fond de la page */
        body {
            background-color: #f9f9f9;
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }

        /* Styles pour le conteneur */
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding-top: 100px;
            text-align: center;
        }

        h2 {
            color: #333;
            margin-bottom: 30px;
        }

        p {
            color: #555;
        }

        a {
            color: #333;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
        
        /* Styles pour le tableau */
        table {
            margin-top: 50px;
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
        }
        
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
        }
        
        th {
            background-color: #f2f2f2;
            font-weight: bold;
            text-align: left;
        }
        
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        .percentage {
            margin-top: 20px;
            font-size: 18px;
        }
        
        /* Styles pour le graphique */
        #chart-container {
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Tableau de bord</h2>
        <p>Bienvenue <?php echo $_SESSION ["user"];   ?> dans votre tableau de bord.</p>
        
        <?php
            // Connexion à la base de données
            require_once '../config/database.php';
        
            // Comptage du nombre total d'utilisateurs
            $stmt = $pdo->query("SELECT COUNT(*) AS total FROM personnels");
            $result = $stmt->fetch();
            $totalUtilisateurs = $result['total'];
            
            // Récupération des utilisateurs
            $stmt = $pdo->query("SELECT nom, prenom, adresse, email FROM personnels");
            $utilisateurs = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Calcul du pourcentage d'utilisateurs inscrits
            $pourcentageInscrits = ($totalUtilisateurs > 0) ? (count($utilisateurs) / $totalUtilisateurs) * 100 : 0;
        ?>
        
        <?php if (!empty($utilisateurs)) : ?>
            <table>
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Prénom</th>
                        <th>Adresse</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($utilisateurs as $utilisateur) : ?>
                        <tr>
                            <td><?php echo $utilisateur['nom']; ?></td>
                            <td><?php echo $utilisateur['prenom']; ?></td>
                            <td><?php echo $utilisateur['adresse']; ?></td>
                            <td><?php echo $utilisateur['email']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <p class="percentage"><?php echo "Pourcentage d'utilisateurs inscrits : " . round($pourcentageInscrits, 2) . "%"; ?></p>
            
            <!-- Graphique pour les nouveaux utilisateurs -->
            <?php
                // Récupération des données pour le graphique
                $stmt = $pdo->query("SELECT DATE(date_recrutement) AS date, COUNT(*) AS count FROM personnels GROUP BY DATE(date_recrutement) ORDER BY DATE(date_recrutement) DESC LIMIT 2");
                $nouveauxUtilisateurs = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                $dates = array();
                $counts = array();
                foreach ($nouveauxUtilisateurs as $row) {
                    $dates[] = $row['date'];
                    $counts[] = $row['count'];
                }
            ?>
            
            <div id="chart-container">
                <canvas id="new-users-chart"></canvas>
            </div>
            
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <script>
                // Configuration du graphique pour les nouveaux utilisateurs
                var ctx = document.getElementById('new-users-chart').getContext('2d');
                var chart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: <?php echo json_encode(array_reverse($dates)); ?>,
                        datasets: [{
                            label: 'Nouveaux utilisateurs',
                            data: <?php echo json_encode(array_reverse($counts)); ?>,
                            backgroundColor: 'rgba(0, 123, 255, 0.2)',
                            borderColor: 'rgba(0, 123, 255, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            x: {
                                type: 'time',
                                time: {
                                    unit: 'day'
                                },
                                display: true,
                                ticks: {
                                    source: 'auto'
                                }
                            },
                            y: {
                                beginAtZero: true,
                                display: true,
                                ticks: {
                                    precision: 0
                                }
                            }
                        }
                    }
                });
            </script>
        <?php else : ?>
            <p>Aucun utilisateur trouvé.</p>
        <?php endif; ?>
        
        <p>Vous pouvez ajouter du contenu ou effectuer d'autres actions spécifiques à votre application ici.</p>
        <p>Vous pouvez également vous déconnecter en cliquant sur le lien ci-dessous.</p>
        <p><a href="deconnexion.php">Se déconnecter</a></p>
    </div>
</body>
</html>
