<!DOCTYPE html>
<html>
<head>
    <title>Confirmation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
    <style>
        /* Styles CSS personnalisés */

        /* Styles pour le fond de la page */
        body {
            background-color: #f9f9f9;
            background-image: url('https://image.freepik.com/vetores-gratis/ilustracao-do-conceito-isometrico-de-ciberseguranca_114482-111.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }

        /* Styles pour le conteneur */
        .container {
            max-width: 400px;
            margin: 0 auto;
            padding-top: 100px;
            text-align: center;
        }

        h2 {
            color: #333;
            margin-bottom: 30px;
        }

        p {
            color: #555;
        }

        a {
            color: #333;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Inscription réussie</h2>
        <p>Votre inscription a été enregistrée avec succès.</p>
        <p>Vous pouvez maintenant vous connecter en utilisant vos identifiants.</p>
        <p>Accédez à la page de connexion : <a href="../views/connexion.php">Connexion</a></p>
    </div>
</body>
</html>
