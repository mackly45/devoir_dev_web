<?php
session_start ();
require_once '../config/database.php';

class ConnexionController
{
    private $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function afficherFormulaire()
    {
        // Affichage du formulaire de connexion
        include '../views/connexion.php';
    }

    public function traiterFormulaire($email, $motDePasse)
    {
        // Recherche de l'utilisateur dans la base de données en utilisant une requête préparée pour se protéger contre les injections SQL
        $stmt = $this->db->prepare("SELECT * FROM personnels WHERE email = ?");
        $stmt->execute([$email]);
        $utilisateur = $stmt->fetch();

        // Vérification du mot de passe
        if ($utilisateur && password_verify($motDePasse, $utilisateur['mot_de_passe'])) {
            // Décryptage du mot de passe pour l'utiliser ultérieurement si nécessaire
            $motDePasseDecrypte = password_hash($motDePasse, PASSWORD_DEFAULT);
            $_SESSION ["user"]=$utilisateur['nom'];
            // Authentification réussie, rediriger vers le tableau de bord
            header("Location: ../views/dashboard.php");
            exit();
        } else {
            // Authentification échouée, afficher un message d'erreur
            $erreur = "Adresse email ou mot de passe incorrect.";
            $this->afficherFormulaire();
            return;
        }
    }
}

// Création de l'instance de la classe ConnexionController avec la connexion à la base de données
$connexionController = new ConnexionController($pdo);

// Vérification de la soumission du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération des données du formulaire
    $email = $_POST['email'];
    $motDePasse = $_POST['mot_de_passe'];

    // Traitement du formulaire
    $connexionController->traiterFormulaire($email, $motDePasse);
} else {
    // Affichage du formulaire de connexion
    $connexionController->afficherFormulaire();
}
?>
