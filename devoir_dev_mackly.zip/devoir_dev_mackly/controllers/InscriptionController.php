<?php

require_once '../models/Personnel.php';
require_once '../config/database.php';

class InscriptionController
{
    private $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function afficherFormulaire()
    {
        // Affichage du formulaire d'inscription
        include '../views/inscription.php';
    }

    public function traiterFormulaire($nom, $prenom, $adresse, $email, $numMobile, $motDePasse, $dateRecrutement)
    {
        // Vérification des données saisies

        // Vérification du format de l'adresse email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $erreur = "L'adresse email n'est pas valide.";
            $this->afficherFormulaire();
            return;
        }

        // Préparation de la requête d'insertion avec des paramètres pour se protéger contre les injections SQL
        $query = "INSERT INTO personnels (nom, prenom, adresse, email, num_mobile, mot_de_passe, date_recrutement) 
                  VALUES (:nom, :prenom, :adresse, :email, :numMobile, :motDePasse, :dateRecrutement)";

        // Hashage du mot de passe
        $motDePasseHash = password_hash($motDePasse, PASSWORD_DEFAULT);

        try {
            // Exécution de la requête préparée
            $stmt = $this->db->prepare($query);
            $stmt->execute([
                'nom' => $nom,
                'prenom' => $prenom,
                'adresse' => $adresse,
                'email' => $email,
                'numMobile' => $numMobile,
                'motDePasse' => $motDePasseHash,
                'dateRecrutement' => $dateRecrutement,
            ]);

            // Redirection vers la page de confirmation
            header("Location: ../views/confirmation.php");
            exit();
        } catch (PDOException $e) {
            die("Erreur lors de l'enregistrement dans la base de données : " . $e->getMessage());
        }
    }
}

// Création de l'instance de la classe InscriptionController avec la connexion à la base de données
$inscriptionController = new InscriptionController($pdo);

// Vérification de la soumission du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération des données du formulaire
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $adresse = $_POST['adresse'];
    $email = $_POST['email'];
    $numMobile = $_POST['num_mobile'];
    $motDePasse = $_POST['mot_de_passe'];
    $dateRecrutement = $_POST['date_recrutement'];

    // Traitement du formulaire
    $inscriptionController->traiterFormulaire($nom, $prenom, $adresse, $email, $numMobile, $motDePasse, $dateRecrutement);
} else {
    // Affichage du formulaire d'inscription
    $inscriptionController->afficherFormulaire();
}
?>
