<?php

class Personnel
{
    private $db;
    private $id;
    private $nom;
    private $prenom;
    private $adresse;
    private $email;
    private $numMobile;
    private $motDePasse;
    private $dateRecrutement;

    public function __construct(PDO $db)
    {
        $this->db = $db;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    public function setNom($nom)
    {
        $this->nom = $nom;
    }

    public function setPrenom($prenom)
    {
        $this->prenom = $prenom;
    }

    public function setAdresse($adresse)
    {
        $this->adresse = $adresse;
    }

    public function setEmail($email)
    {
        $this->email = $email;
    }

    public function setNumMobile($numMobile)
    {
        $this->numMobile = $numMobile;
    }

    public function setMotDePasse($motDePasse)
    {
        // Hashage du mot de passe avant de le stocker
        $this->motDePasse = password_hash($motDePasse, PASSWORD_DEFAULT);
    }

    public function setDateRecrutement($dateRecrutement)
    {
        $this->dateRecrutement = $dateRecrutement;
    }

    public function enregistrer()
    {
        $stmt = $this->db->prepare("INSERT INTO personnels (nom, prenom, adresse, email, num_mobile, mot_de_passe, date_recrutement) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$this->nom, $this->prenom, $this->adresse, $this->email, $this->numMobile, $this->motDePasse, $this->dateRecrutement]);
    }
}

?>
